package com.example.faqscreen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import com.example.faqscreen.ui.theme.FAQScreenTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FAQScreenTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "FAQ Screen",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {

    Column (modifier = modifier) {
        // Add a banner image at the top
        Image(
            painter = painterResour(id = R.drawable.hotel_faq_banner),
            contentDescription = "FAQ Banner",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )

        Text(text = "Frequently Asked Questions", style = MaterialTheme.typography.titleSmall)
        Text(
            text = "Hello $ FAQ Screen!",
            style = MaterialTheme.typography.labelLarge,
            modifier = modifier
        )
        Text(
            text = "You can book a room by selecting your check-in and check-out dates, "
                    + "choosing a room type, and completing the payment process.",
            style = MaterialTheme.typography.labelLarge
        )
        Text(
            text = "2. Can I cancel my booking?",
            style = MaterialTheme.typography.labelLarge,
            modifier = modifier
        )
        Text(
            text = "Yes, you can cancel your booking from your account dashboard up to 24 hours "
                    + "before your check-in date.",
            style = MaterialTheme.typography.labelSmall
        )
        Text(
            text = "3. Are pets allowed in the hotel?",
            style = MaterialTheme.typography.bodySmall,
            modifier = modifier
        )
        Text(
            text = "Yes, we have pet-friendly rooms available. Please select the pet option when booking.",
            style = MaterialTheme.typography.bodyMedium
        )
    }


}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    FAQScreenTheme {
        Greeting("FAQ Screen")
    }
}